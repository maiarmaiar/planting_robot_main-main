class AppRoute {
  static const String login = "/login";
  static const String signup = "/signup";
  static const String onBoard = "/onBoard";
  static const String Forgotpass = "/forgotpass";
  static const String Home = "/home";
  static const String Otp = "/otp";
  static const String ConnectionLost = "/cl";
  static const String Profile = "/profilpic";





}
