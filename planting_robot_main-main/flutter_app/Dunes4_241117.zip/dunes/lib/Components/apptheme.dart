import 'package:flutter/material.dart';

ThemeData themeEnglish = ThemeData(
  fontFamily: "BebasNeue",
);

ThemeData themeArabic = ThemeData(
  fontFamily: "Cairo",
);
