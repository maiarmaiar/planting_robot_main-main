package com.example.dune

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
