import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';
import 'package:percent_indicator/percent_indicator.dart';

class LedControlScreen extends StatefulWidget {
  const LedControlScreen({super.key});

  @override
  State<LedControlScreen> createState() => _LedControlScreenState();
}

class _LedControlScreenState extends State<LedControlScreen> {
  final DatabaseReference _databaseReference =
      FirebaseDatabase.instance.ref().child('Data');
  int temperature = 0;
  int humidity = 0;
  int mq7 = 0;
  int distance = 0;

  @override
  void initState() {
    super.initState();
    _getTemp();
    _getDistance();
    _getGas();
    _getHum();
  }

  void _getTemp() {
    _databaseReference.child('Temp').onValue.listen((event) {
      final int temp = (event.snapshot.value as int?) ?? 0;
      setState(() {
        temperature = temp;
      });
    });
  }

  void _getGas() {
    _databaseReference.child('MQ').onValue.listen((event) {
      final int Mq = (event.snapshot.value as int?) ?? 0;
      setState(() {
        mq7 = Mq;
      });
    });
  }

  void _getDistance() {
    _databaseReference.child('Distance').onValue.listen((event) {
      final int Dis = (event.snapshot.value as int?) ?? 0;
      setState(() {
        distance = Dis;
      });
    });
  }

  void _getHum() {
    _databaseReference.child('Hum').onValue.listen((event) {
      final int hum = (event.snapshot.value as int?) ?? 0;
      setState(() {
        humidity = hum;
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('S E N S O R S'),
        backgroundColor: Colors.blue,
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Padding(
                padding: EdgeInsets.all(8),
                child: Row(
                  children: [
                    Expanded(
                      child: Column(
                        children: [
                          CircularPercentIndicator(
                            radius: 80.0,
                            lineWidth: 15.0,
                            percent: temperature / 100,
                            center: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Icon(
                                  Icons.thermostat,
                                  size: 30.0,
                                  color: Colors.purple,
                                ),
                                SizedBox(width: 5),
                                Text(
                                  '$temperature°',
                                  style: TextStyle(
                                      fontSize: 30, fontWeight: FontWeight.bold),
                                ),
                              ],
                            ),
                            progressColor: Colors.purple,
                            backgroundColor: Colors.grey[300]!,
                          ),
                          Text('Temperature', style: TextStyle(fontSize: 18)),
                        ],
                      ),
                    ),
                    Expanded(
                      child: Column(
                        children: [
                          CircularPercentIndicator(
                            radius: 80.0,
                            lineWidth: 15.0,
                            percent: humidity / 100,
                            center: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Icon(
                                  Icons.water_drop,
                                  size: 30.0,
                                  color: Colors.blue,
                                ),
                                SizedBox(width: 5),
                                Text(
                                  '$humidity°',
                                  style: TextStyle(
                                      fontSize: 30, fontWeight: FontWeight.bold),
                                ),
                              ],
                            ),
                            progressColor: Colors.blue,
                            backgroundColor: Colors.grey[300]!,
                          ),
                          Text('Humidity', style: TextStyle(fontSize: 18)),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              SizedBox(height: 20),
              Padding(
                padding: EdgeInsets.all(8),
                child: Row(
                  children: [
                    Expanded(
                      child: Column(
                        children: [
                          CircularPercentIndicator(
                            radius: 80.0,
                            lineWidth: 15.0,
                            percent: distance / 100,
                            center: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Icon(
                                  Icons.social_distance_sharp,
                                  size: 30.0,
                                  color: Colors.pink,
                                ),
                                SizedBox(width: 5),
                                Text(
                                  '$distance',
                                  style: TextStyle(
                                      fontSize: 30, fontWeight: FontWeight.bold),
                                ),
                              ],
                            ),
                            progressColor: Colors.pink,
                            backgroundColor: Colors.grey[300]!,
                          ),
                          Text('Dust', style: TextStyle(fontSize: 18)),
                        ],
                      ),
                    ),
                    Expanded(
                      child: Column(
                        children: [
                          CircularPercentIndicator(
                            radius: 80.0,
                            lineWidth: 15.0,
                            percent: mq7 == 1 ? 1.0 : mq7 / 100,
                            center: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Icon(
                                  Icons.gas_meter,
                                  size: 30.0,
                                  color: Colors.orange,
                                ),
                                SizedBox(width: 5),
                                Text(
                                  mq7 == 0 ? 'S' : 'D',
                                  style: TextStyle(
                                    fontSize: 30,
                                    fontWeight: FontWeight.bold,
                                    color: mq7 == 0 ? Colors.green : Colors.red,
                                  ),
                                ),
                              ],
                            ),
                            progressColor: Colors.orange,
                            backgroundColor: Colors.grey[300]!,
                          ),
                          Text('Air Quality', style: TextStyle(fontSize: 18)),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
