import 'dart:async';
import 'package:firebase_database/firebase_database.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';

class CameraControl extends StatefulWidget {
  const CameraControl({super.key});

  @override
  State<CameraControl> createState() => _CameraControlState();
}

class _CameraControlState extends State<CameraControl> {
  final DatabaseReference _databaseReference =
      FirebaseDatabase.instance.ref().child('Data');
  bool forwardStatus = false;
  bool backwardStatus = false;
  bool rightStatus = false;
  bool leftStatus = false;
  bool stopStatus = false; // New status variable for stop
  String imageUrl = '';
  String previousImageUrl = '';
  Timer? _imageRefreshTimer;

  @override
  void initState() {
    super.initState();
    _fetchImage();
    _imageRefreshTimer = Timer.periodic(const Duration(seconds: 2), (timer) {
      _fetchImage();
    });
    forwardStatus = false;
    backwardStatus = false;
    rightStatus = false;
    leftStatus = false;
    stopStatus = false;
    _databaseReference.child('cam_left').set(forwardStatus);
    _databaseReference.child('cam_right').set(backwardStatus);
    _databaseReference.child('cam_up').set(leftStatus);
    _databaseReference.child('cam_down').set(rightStatus);
    _databaseReference.child('cam_center').set(stopStatus);
    _databaseReference.child('cam_capture').set(stopStatus);
  }

  Future<String> _getImageUrl() async {
    try {
      final ref = FirebaseStorage.instance.ref().child('camera_frames/live_stream.jpg');
      return await ref.getDownloadURL();
    } catch (e) {
      print('Error fetching image: $e');
      return '';
    }
  }

  void _fetchImage() async {
    final newImageUrl = await _getImageUrl();

    if (mounted) {
      setState(() {
        previousImageUrl = imageUrl;
        imageUrl = newImageUrl;
      });
    }
  }

   void _toggleForward() {
    setState(() {
      forwardStatus = !forwardStatus;
    });
    _databaseReference.child('cam_up').set(forwardStatus);
  }

  void _toggleBackward() {
    setState(() {
      backwardStatus = !backwardStatus;
    });
    _databaseReference.child('cam_down').set(backwardStatus);
  }

  void _toggleLeft() {
    setState(() {
      leftStatus = !leftStatus;
    });
    _databaseReference.child('cam_left').set(leftStatus);
  }

  void _toggleRight() {
    setState(() {
      rightStatus = !rightStatus;
    });
    _databaseReference.child('cam_right').set(rightStatus);
  }

  void _toggleStop() {
  setState(() {
    stopStatus = true; // Set stopStatus to true
  });
  _databaseReference.child('cam_center').set(stopStatus); // Update Firebase with true

  // After 1 second, switch stopStatus back to false
  Timer(const Duration(seconds: 1), () {
    setState(() {
      stopStatus = false; // Set stopStatus back to false
    });
    _databaseReference.child('cam_center').set(stopStatus); // Update Firebase with false
  });
}



  @override
  void dispose() {
    _imageRefreshTimer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Camera Feed'),
        backgroundColor: Colors.blue,
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            Stack(
              alignment: Alignment.center,
              children: [
                if (previousImageUrl.isNotEmpty)
                  Image.network(
                    previousImageUrl,
                    key: UniqueKey(),
                    fit: BoxFit.cover,
                  ),
                if (imageUrl.isNotEmpty)
                  Image.network(
                    imageUrl,
                    key: UniqueKey(),
                    fit: BoxFit.cover,
                  ),
                if (imageUrl.isEmpty)
                  const CircularProgressIndicator(),
              ],
            ),
              const SizedBox(
                height: 30,
              ),
              IconButton(
                onPressed: _toggleForward,
                icon: Icon(Icons.arrow_circle_up),
                color: forwardStatus ? Colors.yellow : Colors.black,
                iconSize: 70,
              ),
              Row(
                children: [
                  Expanded(
                    child: IconButton(
                      onPressed: _toggleLeft,
                      icon: Icon(Icons.arrow_circle_left),
                      color: leftStatus ? Colors.yellow : Colors.black,
                      iconSize: 70,
                    ),
                  ),
                  Expanded(
                    child: IconButton(
                      onPressed:
                          _toggleStop, // Add button for stop functionality
                      icon: Icon(Icons.stop), // Change icon as needed
                      color: stopStatus ? Colors.red : Colors.black,
                      iconSize: 70, // Indicate stop status
                    ),
                  ),
                  Expanded(
                    child: IconButton(
                      onPressed: _toggleRight,
                      icon: Icon(Icons.arrow_circle_right),
                      color: rightStatus ? Colors.yellow : Colors.black,
                      iconSize: 70,
                    ),
                  ),
                ],
              ),
              IconButton(
                onPressed: _toggleBackward,
                icon: Icon(Icons.arrow_circle_down),
                color: backwardStatus ? Colors.yellow : Colors.black,
                iconSize: 70,
              ),
          ],
        ),
      ),
    );
  }
}
