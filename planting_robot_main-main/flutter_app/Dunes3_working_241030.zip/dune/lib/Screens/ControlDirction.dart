import 'dart:async';

import 'package:firebase_database/firebase_database.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';

class Directions extends StatefulWidget {
  const Directions({super.key});

  @override
  State<Directions> createState() => _DirectionsState();
}

class _DirectionsState extends State<Directions> {
  String imageUrl = '';
  String previousImageUrl = '';
  Timer? _imageRefreshTimer;

  Future<String> _getImageUrl() async {
    try {
      final ref =
          FirebaseStorage.instance.ref().child('camera_frames/live_stream.jpg');
      return await ref.getDownloadURL();
    } catch (e) {
      print('Error fetching image: $e');
      return '';
    }
  }

  void _fetchImage() async {
    final newImageUrl = await _getImageUrl();

    if (mounted) {
      setState(() {
        previousImageUrl = imageUrl;
        imageUrl = newImageUrl;
      });
    }
  }

  @override
  void dispose() {
    _imageRefreshTimer?.cancel();
    super.dispose();
  }

  final DatabaseReference _databaseReference =
      FirebaseDatabase.instance.ref().child('Data');
  bool forwardStatus = false;
  bool backwardStatus = false;
  bool rightStatus = false;
  bool leftStatus = false;
  bool stopStatus = true; // New status variable for stop

  @override
  void initState() {
    super.initState();
    forwardStatus = false;
    backwardStatus = false;
    rightStatus = false;
    leftStatus = false;
    stopStatus = true;
    _databaseReference.child('forward').set(forwardStatus);
    _databaseReference.child('backward').set(backwardStatus);
    _databaseReference.child('left').set(leftStatus);
    _databaseReference.child('right').set(rightStatus);
    _databaseReference.child('stop').set(stopStatus);

    super.initState();
    _fetchImage();

    // Refresh image every 2 seconds
    _imageRefreshTimer = Timer.periodic(Duration(seconds: 2), (timer) {
      _fetchImage();
    });
  }

  void _toggleForward() {
    setState(() {
      forwardStatus = !forwardStatus;
    });
    _databaseReference.child('forward').set(forwardStatus);
  }

  void _toggleBackward() {
    setState(() {
      backwardStatus = !backwardStatus;
    });
    _databaseReference.child('backward').set(backwardStatus);
  }

  void _toggleLeft() {
    setState(() {
      leftStatus = !leftStatus;
    });
    _databaseReference.child('left').set(leftStatus);
  }

  void _toggleRight() {
    setState(() {
      rightStatus = !rightStatus;
    });
    _databaseReference.child('right').set(rightStatus);
  }

  void _toggleStop() {
    setState(() {
      stopStatus = !stopStatus; // Toggle the stop status
    });
    _databaseReference
        .child('stop')
        .set(stopStatus); // Update the stop status in Firebase
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
       appBar: AppBar(
        title: const Text('Camera Feed'),
        backgroundColor: Colors.blue,
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        child: Center(
          child: Column(
            children: [
              Center(
                child: Stack(
                  alignment: Alignment.center,
                  children: [
                    if (previousImageUrl.isNotEmpty)
                      Image.network(
                        previousImageUrl,
                        key: UniqueKey(),
                        fit: BoxFit.cover,
                      ),
                    if (imageUrl.isNotEmpty)
                      Image.network(
                        imageUrl,
                        key: UniqueKey(),
                        fit: BoxFit.cover,
                      ),
                    // Optional: You can add a loading indicator while fetching the image
                    if (imageUrl.isEmpty) CircularProgressIndicator(),
                  ],
                ),
              ),
              const SizedBox(
                height: 30,
              ),
              IconButton(
                onPressed: _toggleForward,
                icon: Icon(Icons.arrow_circle_up),
                color: forwardStatus ? Colors.yellow : Colors.black,
                iconSize: 70,
              ),
              Row(
                children: [
                  Expanded(
                    child: IconButton(
                      onPressed: _toggleLeft,
                      icon: Icon(Icons.arrow_circle_left),
                      color: leftStatus ? Colors.yellow : Colors.black,
                      iconSize: 70,
                    ),
                  ),
                  Expanded(
                    child: IconButton(
                      onPressed:
                          _toggleStop, // Add button for stop functionality
                      icon: Icon(Icons.stop), // Change icon as needed
                      color: stopStatus ? Colors.red : Colors.black,
                      iconSize: 70, // Indicate stop status
                    ),
                  ),
                  Expanded(
                    child: IconButton(
                      onPressed: _toggleRight,
                      icon: Icon(Icons.arrow_circle_right),
                      color: rightStatus ? Colors.yellow : Colors.black,
                      iconSize: 70,
                    ),
                  ),
                ],
              ),
              IconButton(
                onPressed: _toggleBackward,
                icon: Icon(Icons.arrow_circle_down),
                color: backwardStatus ? Colors.yellow : Colors.black,
                iconSize: 70,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
