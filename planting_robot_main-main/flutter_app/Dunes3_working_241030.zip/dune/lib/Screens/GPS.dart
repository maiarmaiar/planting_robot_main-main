import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:geolocator/geolocator.dart';
import 'package:latlong2/latlong.dart';

class FindGps extends StatefulWidget {
  const FindGps({super.key});

  @override
  State<FindGps> createState() => _FindGpsState();
}

class _FindGpsState extends State<FindGps> {
  final DatabaseReference _databaseReference =
      FirebaseDatabase.instance.ref().child('Data');
  bool forwardStatus = false;
  bool backwardStatus = false;
  LatLng _defaultLocation = LatLng(51.5, -0.09); // Default location for the map
  LatLng? _currentLocation; // Current location after fetching
  double _zoomLevel = 13.0; // Initial zoom level
  final MapController _mapController = MapController();

  @override
  void initState() {
    super.initState();
    forwardStatus = false;
    backwardStatus = false;
    _databaseReference.child('forward').set(forwardStatus);
    _databaseReference.child('backward').set(backwardStatus);
    _toggleBackward(); // Initialize backward status
    _getCurrentLocation(); // Fetch current location on init
  }

  void _toggleForward() {
    setState(() {
      forwardStatus = !forwardStatus;
    });
    _databaseReference.child('forward').set(forwardStatus);
  }

  void _toggleBackward() {
    setState(() {
      backwardStatus = !backwardStatus;
    });
    _databaseReference.child('backward').set(backwardStatus);
  }

  Future<void> _getCurrentLocation() async {
    LocationPermission permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.whileInUse ||
        permission == LocationPermission.always) {
      _fetchLocation(); // Fetch location directly
    } else if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.whileInUse ||
          permission == LocationPermission.always) {
        _fetchLocation();
      }
    } else if (permission == LocationPermission.deniedForever) {
      _showPermissionDeniedDialog();
    }
  }

  Future<void> _fetchLocation() async {
    Position position = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.high);
    setState(() {
      _currentLocation = LatLng(position.latitude, position.longitude);
      _zoomLevel = 15.0;
    });
    _mapController.move(_currentLocation!, _zoomLevel);
  }

  void _showPermissionDeniedDialog() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Permission Denied'),
          content: const Text(
              'Location permission is permanently denied. Please enable location permission from the settings.'),
          actions: [
            ElevatedButton(
              onPressed: () {
                Navigator.pop(context);
              },
              child: const Text('Close'),
            ),
          ],
        );
      },
    );
  }

  void _showLocationDetails() {
    if (_currentLocation != null) {
      showModalBottomSheet(
        context: context,
        builder: (BuildContext context) {
          return Container(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Location Details',
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 10),
                Text('Latitude: ${_currentLocation!.latitude}'),
                Text('Longitude: ${_currentLocation!.longitude}'),
                const SizedBox(height: 20),
                ElevatedButton(
                  onPressed: () {
                    Navigator.pop(context);
                  },
                  child: const Text('Close'),
                ),
              ],
            ),
          );
        },
      );
    } else {
      showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            title: const Text('Location Not Available'),
            content: const Text('Unable to fetch the current location.'),
            actions: [
              ElevatedButton(
                onPressed: () {
                  Navigator.pop(context);
                },
                child: const Text('Close'),
              ),
            ],
          );
        },
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          Expanded(
            child: Stack(
              children: [
                FlutterMap(
                  mapController: _mapController,
                  options: MapOptions(
                    center: _currentLocation ?? _defaultLocation,
                    zoom: _zoomLevel,
                  ),
                  children: [
                    TileLayer(
                      urlTemplate:
                          'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',
                    ),
                    MarkerLayer(
                      markers: [
                        Marker(
                          point: _currentLocation ?? _defaultLocation,
                          width: 80,
                          height: 80,
                          builder: (ctx) => const Icon(
                            Icons.location_pin,
                            color: Colors.red,
                            size: 40,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
                Positioned(
                  bottom: 20,
                  right: 20,
                  child: FloatingActionButton(
                    onPressed: _showLocationDetails,
                    child: const Icon(Icons.info),
                  ),
                ),
              ],
            ),
          ),
          SizedBox(height: 20),
          Row(
            children: [
              Expanded(
                child: IconButton(
                  icon: Icon(
                    Icons.agriculture,
                    color: backwardStatus ? Colors.green : Colors.black,
                    size: 80,
                  ),
                  onPressed: _toggleBackward,
                ),
              ),
              Expanded(
                child: IconButton(
                  icon: Icon(
                    Icons.grass,
                    color: forwardStatus ? Colors.green : Colors.black,
                    size: 80,
                  ),
                  onPressed: _toggleForward,
                ),
              ),
            ],
          ),
          SizedBox(height: 20),
        ],
      ),
    );
  }
}
